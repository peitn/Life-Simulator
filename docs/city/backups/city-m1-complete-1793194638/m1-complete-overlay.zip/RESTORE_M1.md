# Life Simulator — completed M1 recovery overlay

This is a city-only overlay for the existing Godot project `lifesim`.
It is not a standalone game and does not replace the existing main project.
It preserves the native Blender finishing kit, original new maps/GLBs,
source generators, tested city scripts, accepted previews and M1/M2 handoff.

1. Acquire the project's protocol-v3 city lease; back up existing city files.
2. Compare newer server files before merging; never overwrite unrelated work.
   The previous baseline stair source before this change had SHA-256
   `e8a8864661f467f04cf4536a4c3bd966a69f9499451ded12741ba0e4a58f3333`.
3. Merge the overlay folders into `lifesim`. Existing city scene/model files,
   the automation coordinator and the main project's autoloads are required.
4. Rebuild only the new saved scenes with:
   `godot --headless --path LIFESIM --script res://scripts/city/build_m1_finish.gd -- RUN_ID`
5. Run the real acceptance runner under that same owned lease:
   `godot --headless --path LIFESIM --script res://scripts/city/validate_m1_suite.gd -- RUN_ID`
   Expected: `M1_SUITE 27/27 failed=0`, with1193positive checks and checked negative controls.
6. Read `docs/city/M1_ACCEPTANCE_20261028.md` and continue from `M2_START.md`.
   Release only the owned lease and keep the backup limitation explicit.

To regenerate native finishing assets independently:
`blender --background --python tools/blender/city/m1_finish.py`.
Textures are packed into the editable `.blend`; generation output paths are
relative to this overlay root or `LIFESIM_M1_ROOT`. Blender4.3.2 was used and
the source `.blend` was reopened and checked. No external textures are needed
to open that native kit.

`SHA256SUMS.json` records the packaged file hashes. Accepted previews are
static real-engine captures, not animation/FPS or final release certification.
